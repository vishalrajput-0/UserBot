# Project Paperplane Extended

### **A modular Telegram userbot running on Python 3.6+ with an sqlalchemy database.**

#### The easiest way to deploy this bad boy !!

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/noobvishal/Userbot/tree/sql-extended)

    #include <std/disclaimer.h>
    /**
        Your Telegram account may get banned.

        I am not responsible for ANY improper use of this bot.

        This userbot is intended for the purpose of having fun with memes,
        as well as efficiently managing groups.

        You ended up spamming groups, getting reported left and right,
        and you ended up in a Finale Battle with Telegram and at the end
        Telegram Team deleted your account?

        And after that, then you pointed your fingers at us
        for getting your acoount deleted?

        I will be rolling on the floor laughing at you.
    /**

This is a fork of the famous [Paperplane](https://github.com/RaphielGang/Telegram-UserBot) userbot made by the awesome [RaphielGang](https://github.com/RaphielGang) team with some extras from the Telegram userbot community.

For setting up and configuring this userbot, you can checkout the [Wiki](https://telegra.ph/How-to-host-a-Telegram-Userbot-07-24)

If you just want to stay in the loop about new features or
announcements you can join the [news channel](https://t.me/PaperplaneExtended).

If you find any bugs or have any suggestions then don’t hesitate to contact me in my [Fan Club](https://t.me/PaperplaneExtendedChat).

### Credits:

I would like to thank people who assisted me throughout this project:

* [@YouTwitFace](https://github.com/YouTwitFace)
* [@TheDevXen](https://github.com/TheDevXen)
* [@Skittles9823](https://github.com/Skittles9823)
* [@deletescape](https://github.com/deletescape)
* [@songotenks69](https://github.com/songotenks69)
* [@Ovenoboyo](https://github.com/Ovenoboyo)
* [@SphericalKat](https://github.com/ATechnoHazard)
* [@nitanmarcell](https://www.github.com/nitanmarcel)
* [@spechide](https://www.github.com/spechide)
* [@Jeepeo](https://github.com/Jeepeo)
* [@shxnpie](https://github.com/shxnpie)
* [@rupansh](https://github.com/rupansh)
* [@zakaryan2004](https://github.com/zakaryan2004)
* [@kandnub](https://github.com/kandnub)
* [@pqhaz](https://github.com/pqhaz)
* [@Zero_cool7870](https://github.com/jaskaranSM)
* [@Prakasaka](https://github.com/Prakasaka)

and many more people and projects who aren’t mentioned here.

All features taken from them are copyrighted to their respespective, if you are handling the features/module
by them you need to strictly comply their respective LICENSE

Found Bugs? Create an issue on the issue tracker, or post it in the [Fan Club](https://t.me/PaperplaneExtendedChat).
